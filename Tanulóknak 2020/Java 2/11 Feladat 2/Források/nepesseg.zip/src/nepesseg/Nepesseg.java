package nepesseg;

public class Nepesseg {

    public static void main(String[] args) {
        // adatok inicializálása
        int[][] nepesseg =
            {
                { 106, 107, 111, 133, 221, 767, 1766 },
                { 502, 635, 809, 947, 1402, 3634, 5268 },
                { 2, 2, 2, 6, 13, 30, 46 },
                { 163, 203, 276, 408, 547, 729, 628 },
                { 2, 7, 26, 82, 172, 307, 392 },
                { 16, 24, 38, 74, 167, 511, 809 }
            };
        String[] foldreszek =
            {
                "Afrika",
                "Ázsia",
                "Ausztrália",
                "Európa",
                "Észak-America",
                "Dél-America"
            };
        // adatok kiírása
        
        // összegzés
        
    }
    
}
